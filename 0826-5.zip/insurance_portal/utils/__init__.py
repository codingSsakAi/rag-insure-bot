"""
Feature: 보험 상식
Purpose: 파일 용도 주석 추가
Notes: 해당 파일은 보험 상식 기능에 사용됩니다.
"""
