from django.apps import AppConfig


class InsurancePortalConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "insurance_portal"
