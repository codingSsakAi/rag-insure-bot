# insurance_portal/views/__init__.py
